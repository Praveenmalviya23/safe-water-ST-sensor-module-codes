/*
 * modbusSlave.h
 *
 *  Created on: JULY 24, 2025
 *      Author: KULDEEP
 */

#ifndef _MODBUS_SLAVE_H
#define _MODBUS_SLAVE_H

#include "modbus_crc.h"


#define ILLEGAL_FUNCTION       0x01
#define ILLEGAL_DATA_ADDRESS   0x02
#define ILLEGAL_DATA_VALUE     0x03

#define PRESS_MAX_ADC 2482.42f
#define PRESS_MIN_ADC	496.48f

#define PRESS_MAX_BAR	2.0f
#define PRESS_MIN_BAR 0.0f


#define ADDR_FLASH_PAGE_0     ((uint32_t)0x08000000) /* Base @ of Page 0, 2 Kbytes */
#define ADDR_FLASH_PAGE_1     ((uint32_t)0x08000800) /* Base @ of Page 1, 2 Kbytes */
#define ADDR_FLASH_PAGE_2     ((uint32_t)0x08001000) /* Base @ of Page 2, 2 Kbytes */
#define ADDR_FLASH_PAGE_3     ((uint32_t)0x08001800) /* Base @ of Page 3, 2 Kbytes */
#define ADDR_FLASH_PAGE_4     ((uint32_t)0x08002000) /* Base @ of Page 4, 2 Kbytes */
#define ADDR_FLASH_PAGE_5     ((uint32_t)0x08002800) /* Base @ of Page 5, 2 Kbytes */
#define ADDR_FLASH_PAGE_6     ((uint32_t)0x08003000) /* Base @ of Page 6, 2 Kbytes */
#define ADDR_FLASH_PAGE_7     ((uint32_t)0x08003800) /* Base @ of Page 7, 2 Kbytes */
#define ADDR_FLASH_PAGE_8     ((uint32_t)0x08004000) /* Base @ of Page 8, 2 Kbytes */
#define ADDR_FLASH_PAGE_9     ((uint32_t)0x08004800) /* Base @ of Page 9, 2 Kbytes */
#define ADDR_FLASH_PAGE_10    ((uint32_t)0x08005000) /* Base @ of Page 10, 2 Kbytes */
#define ADDR_FLASH_PAGE_11    ((uint32_t)0x08005800) /* Base @ of Page 11, 2 Kbytes */
#define ADDR_FLASH_PAGE_12    ((uint32_t)0x08006000) /* Base @ of Page 12, 2 Kbytes */
#define ADDR_FLASH_PAGE_13    ((uint32_t)0x08006800) /* Base @ of Page 13, 2 Kbytes */
#define ADDR_FLASH_PAGE_14    ((uint32_t)0x08007000) /* Base @ of Page 14, 2 Kbytes */
#define ADDR_FLASH_PAGE_15    ((uint32_t)0x08007800) /* Base @ of Page 15, 2 Kbytes */

//#define slave_id_add  (0x08007400)
//#define offset_add    (0x08007420)
//#define scale_add     (0x08007440)

#define slave_id_add (0x08007800)
#define offset_add  (0x08007800)
#define scale_add  (0x08007810)
#define scale_3_add  (0x08007810)
#define offset_1_add (0x08007880)
#define offset_2_add (0x080078A0)
#define offset_3_add (0x080078C0)


//#define slave_id_add (0x08007800)
//#define offset_add  (0x08007820)
//#define scale_add  (0x08007840)
//#define scale_1_add  (0x08007820)
//#define scale_2_add  (0x08007840)
//#define scale_3_add  (0x08007860)
//#define offset_1_add (0x08007880)
//#define offset_2_add (0x080078A0)
//#define offset_3_add (0x080078C0)

#define FLASH_USER_START_ADDR   ADDR_FLASH_PAGE_15   /* Start @ of user Flash area */
#define FLASH_USER_END_ADDR     (ADDR_FLASH_PAGE_15 + FLASH_PAGE_SIZE - 1)   /* End @ of user Flash area */

#define DATA_32                 ((uint32_t)0x12345678)
#define DATA_64                 ((uint64_t)0x1234567812345678)


uint8_t readHoldingRegs (void);
uint8_t readInputRegs (void);
uint8_t readCoils (void);
uint8_t readInputs (void);

uint8_t writeSingleReg (void);
uint8_t writeHoldingRegs (void);
uint8_t writeSingleCoil (void);
uint8_t writeMultiCoils (void);

void fillDataIntoHoldingRegister(void);
void readDataFromFlash(void);
void modbusException (uint8_t exceptioncode);
float map_float(uint16_t x, float in_min, float in_max, float out_min, float out_max);
void convertToPH(void);
uint8_t writeInFlash(uint32_t startAdd, uint64_t data);
#endif
