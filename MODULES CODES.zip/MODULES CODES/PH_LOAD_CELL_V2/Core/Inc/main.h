/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32c0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LED_2_Pin GPIO_PIN_7
#define LED_2_GPIO_Port GPIOB
#define LC_DOUT_Pin GPIO_PIN_14
#define LC_DOUT_GPIO_Port GPIOC
#define LC_SCK_Pin GPIO_PIN_15
#define LC_SCK_GPIO_Port GPIOC
#define LED_1_Pin GPIO_PIN_0
#define LED_1_GPIO_Port GPIOA
#define PH_EN_Pin GPIO_PIN_1
#define PH_EN_GPIO_Port GPIOA
#define PH_B_Pin GPIO_PIN_2
#define PH_B_GPIO_Port GPIOA
#define PH_A_Pin GPIO_PIN_3
#define PH_A_GPIO_Port GPIOA
#define RS485_TX_Pin GPIO_PIN_4
#define RS485_TX_GPIO_Port GPIOA
#define RS485_RX_Pin GPIO_PIN_5
#define RS485_RX_GPIO_Port GPIOA
#define RS485_RE_Pin GPIO_PIN_6
#define RS485_RE_GPIO_Port GPIOA

/* USER CODE BEGIN Private defines */
#define MODBUS_SLAVE_ID 4

typedef struct {
    double calibration_factor;
    double offset;
		uint16_t actWeight;
    // You can add other configurations here if needed, like gain
} HX711_Config_t;

#define hx711_data_Pin GPIO_PIN_14   //
#define hx711_data_GPIO_Port GPIOC   // 
#define hx711_sck_Pin GPIO_PIN_15    //
#define hx711_sck_GPIO_Port GPIOC    //

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
