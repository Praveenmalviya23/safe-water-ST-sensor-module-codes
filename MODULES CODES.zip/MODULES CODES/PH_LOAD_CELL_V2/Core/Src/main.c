/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdbool.h>
#include <stdio.h> // Required for printf
#include <math.h>  // Required for fmax and fmin (or you can implement them manually)
#include "modbusSlave.h"
#include "modbus_crc.h"
#include "FLASH_PAGE_F1.h"
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define HX711_DOUT_Pin hx711_data_Pin
#define HX711_DOUT_GPIO_Port hx711_data_GPIO_Port
#define HX711_SCK_Pin hx711_sck_Pin
#define HX711_SCK_GPIO_Port hx711_sck_GPIO_Port
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

HX711_Config_t _hx711;

volatile uint8_t RxData[50];
volatile uint8_t TxData[50];

uint8_t  SLAVE_ID = MODBUS_SLAVE_ID;

volatile bool tare_hx711;
volatile bool calib_hx711;


volatile bool tare_hx711_flag;
volatile bool calib_hx711_flag;

volatile uint16_t tare_hx711_val;
volatile uint16_t known_weight_val;
volatile uint16_t calib_hx711_val;



volatile uint16_t adcBuffer[2];
volatile uint16_t AdcConvertedBuffer[2];
volatile bool adcConversionCompleteFlag = false;


volatile float ph_actual;

float scale = 1;
float off;

uint64_t dataToWrite1;
uint64_t dataToWrite2;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void HX711_Delay_us(uint32_t us) {
	// Example using a simple loop (less accurate, but easy to implement)
	// For more accurate delays, consider TIMers or DWT.
	volatile uint32_t counter = us * (SystemCoreClock / 1000000);
	while (counter--);
}

int32_t actualWeight;

// Function to read raw data from HX711
int32_t HX711_Read_Raw(void) {
	uint32_t data = 0;
	int32_t value = 0;

	// Wait for DOUT to go low (data ready)
	while (HAL_GPIO_ReadPin(HX711_DOUT_GPIO_Port, HX711_DOUT_Pin) == GPIO_PIN_SET) {
			// Optional: Add a timeout here to prevent infinite loop
	}

	// Pulse the SCK pin 24 times to read 24 bits
	for (int i = 0; i < 24; i++) {
			HAL_GPIO_WritePin(HX711_SCK_GPIO_Port, HX711_SCK_Pin, GPIO_PIN_SET);
			HX711_Delay_us(1); // Short delay (e.g., 1 us or less)
			data <<= 1;
			if (HAL_GPIO_ReadPin(HX711_DOUT_GPIO_Port, HX711_DOUT_Pin) == GPIO_PIN_SET) {
					data++;
			}
			HAL_GPIO_WritePin(HX711_SCK_GPIO_Port, HX711_SCK_Pin, GPIO_PIN_RESET);
			HX711_Delay_us(1); // Short delay
	}

	// Apply 25th, 26th, or 27th pulse for gain selection (e.g., 25th for GAIN 128 on Channel A)
	// For simplicity, we'll just send 25 pulses for default gain 128 on Channel A
	HAL_GPIO_WritePin(HX711_SCK_GPIO_Port, HX711_SCK_Pin, GPIO_PIN_SET);
	HX711_Delay_us(1);
	HAL_GPIO_WritePin(HX711_SCK_GPIO_Port, HX711_SCK_Pin, GPIO_PIN_RESET);
	HX711_Delay_us(1);

	// Convert 24-bit two's complement to signed 32-bit
	if (data & 0x800000) { // If the 24th bit is set (negative number)
			value = (int32_t)(data | 0xFF000000); // Sign-extend to 32 bits
	} else {
			value = (int32_t)data;
	}

	return value;
}

long HX711_Read(HX711_Config_t* hx711, uint8_t times) {
    long sum = 0;
    for (uint8_t i = 0; i < times; i++) {
        sum += HX711_Read_Raw();
        HAL_Delay(1); // Small delay between readings
    }
    return sum / times; // Average the readings
}

void HX711_Tare(HX711_Config_t* hx711, uint8_t times) {
    long sum = HX711_Read(hx711, times);
    hx711->offset = sum;
}

float HX711_Cal(HX711_Config_t* hx711, uint8_t times) {
  float sum = HX711_Read(hx711, times);
	return sum;
}


void HX711_SetCalibrationFactor(HX711_Config_t* hx711, float factor) {
    hx711->calibration_factor = factor;
}

float HX711_GetWeight(HX711_Config_t* hx711, uint8_t times) {
    long actualWeight = HX711_Read(hx711, times);
    return (float)(actualWeight - hx711->offset) / hx711->calibration_factor;
}

void HX711_PowerDown(void) {
    HAL_GPIO_WritePin(HX711_SCK_GPIO_Port, HX711_SCK_Pin, GPIO_PIN_SET);
    HAL_Delay(100); // Wait for power down to complete (min 60us)
}

void HX711_PowerUp(void) {
    HAL_GPIO_WritePin(HX711_SCK_GPIO_Port, HX711_SCK_Pin, GPIO_PIN_RESET);
    HAL_Delay(100); // Wait for power up to complete (min 60us)
}


void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{

	float volt;
	static uint32_t accSample1;
	static uint32_t accSample2;
	static int counter;
	uint16_t average1;
	uint16_t average2;

	accSample1+=adcBuffer[0];
	accSample2+=adcBuffer[1];
	counter++;
	if(counter == 500){
		counter =0;
		average1 = accSample1/500;
		average2 = accSample2/500;
		accSample1 =0;
		accSample2 =0;
		//volt = (average2 - average1)*3.3f/4095; //original
		volt = ((average2 - average1)*3.3f/4095);
		// ph_actual = 7.0 - ((volt+0.0588278361) * 1000.0 / 59.16); //Original
		ph_actual = 7.0 - ((volt + -0.001260 ) * 1000.0 / 57.8833);
		
			
	}
	
	
}

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	if (RxData[0] == SLAVE_ID)
	{
		switch (RxData[1]){
		case 0x03:
			readHoldingRegs();
			break;
		case 0x04:
			readInputRegs();
			break;
		case 0x01:
			readCoils();
			break;
		case 0x02:
			readInputs();
			break;
		case 0x06:
			writeSingleReg();
			break;
		case 0x10:
			writeHoldingRegs();
			break;
		case 0x05:
			writeSingleCoil();
			break;
		case 0x0F:
			writeMultiCoils();
			break;
		default:
			modbusException(ILLEGAL_FUNCTION);
			break;
		}
	}
	HAL_UARTEx_ReceiveToIdle_IT(&huart2, (uint8_t *)RxData, 50);
}
double test;
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_TIM3_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
	HAL_GPIO_WritePin(PH_EN_GPIO_Port, PH_EN_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(LED_2_GPIO_Port, LED_2_Pin, GPIO_PIN_SET); 
	HAL_Delay(500);

	HAL_ADCEx_Calibration_Start(&hadc1);
  HAL_TIM_Base_Start(&htim3);	
	HAL_ADC_Start_DMA(&hadc1,(uint32_t *)adcBuffer,2);

//	// *** CRITICAL FIX: Set RS485 to Receive Mode (RE/DE LOW) ***
//  HAL_GPIO_WritePin(RS485_RE_GPIO_Port, RS485_RE_Pin, GPIO_PIN_RESET);
//	
//	readDataFromFlash();

	uint64_t tempReadOffset;
	tempReadOffset = *(__IO uint64_t *)(offset_add); // read offset 
//	Holding_Registers_Database[1] =
	if(tempReadOffset == 0xFFFFFFFF)
	tempReadOffset = 0X00;
	else	
	_hx711.offset = tempReadOffset;
//	Holding_Registers_Database[1] = _hx711.offset /1000;
	
	uint64_t tempReadScale;
	tempReadScale = *(__IO uint64_t *)(scale_3_add); // read scale from flash

	if(tempReadScale == 0xFFFFFFFF)
	tempReadScale = 0X01;
	else
	_hx711.calibration_factor = (float)tempReadScale/10000.0f;
	
	
	HX711_SetCalibrationFactor(&_hx711,_hx711.calibration_factor);
	
	HAL_UARTEx_ReceiveToIdle_IT(&huart2, (uint8_t *)RxData, 50);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
			
			// --- Logic pH ---
			HAL_UARTEx_ReceiveToIdle_IT(&huart2, (uint8_t *)RxData, 50);

			// --- Logic Loadcell ---
			if(tare_hx711_flag == true){
					_hx711.calibration_factor = 1;
					_hx711.offset = 0;
					HX711_Tare(&_hx711, 50);
					// store the tare value from _hx711 structure
//					writeInFlash(offset_add, (uint64_t)_hx711.offset);
					off = _hx711.offset;
					HAL_FLASH_Unlock();
					dataToWrite1 = (uint64_t)_hx711.offset;
					uint32_t address = offset_add; // Start of Page 15

					HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, address, dataToWrite1);

					// Lock it back to prevent accidental writes
					HAL_FLASH_Lock();	
				
					tare_hx711_flag = false;
			}
							
			else if(calib_hx711_flag == true){
					
					float temp1 = 0;
					float KnownWeight = (float)(known_weight_val*10.0f);
					temp1 = HX711_GetWeight(&_hx711, 50); 
					scale = temp1 / KnownWeight;
//					scale = scale;
					HX711_SetCalibrationFactor(&_hx711, scale);
//					uint32_t temp = (uint32_t)(scale);
					// store the scale from _hx711 structure
				
					HAL_FLASH_Unlock();
					dataToWrite2 = (scale*10000);
					uint32_t address = scale_3_add; // Start of Page 15

					HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, address, dataToWrite2);

					// Lock it back to prevent accidental writes
					HAL_FLASH_Lock();				
//					writeInFlash(scale_3_add, (uint64_t)temp);
					calib_hx711_flag = false;
			}
			else{
					actualWeight = HX711_GetWeight(&_hx711, 50); 
//					_hx711.actWeight = HX711_Read(&_hx711,50);//actualWeight / 100;
//					if(_hx711.actWeight > 65500)
//							_hx711.actWeight = 0;
			}

			// Common function call - put at the end of the loop to update holding registers with latest data
			fillDataIntoHoldingRegister();
		  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_FLASH_SET_LATENCY(FLASH_LATENCY_1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_SEQ_FIXED;
  hadc1.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.LowPowerAutoPowerOff = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIG_T3_TRGO;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.SamplingTimeCommon1 = ADC_SAMPLETIME_12CYCLES_5;
  hadc1.Init.OversamplingMode = ENABLE;
  hadc1.Init.Oversampling.Ratio = ADC_OVERSAMPLING_RATIO_16;
  hadc1.Init.Oversampling.RightBitShift = ADC_RIGHTBITSHIFT_4;
  hadc1.Init.Oversampling.TriggeredMode = ADC_TRIGGEREDMODE_SINGLE_TRIGGER;
  hadc1.Init.TriggerFrequencyMode = ADC_TRIGGER_FREQ_HIGH;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 48-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 1000-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_2_GPIO_Port, LED_2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LC_SCK_GPIO_Port, LC_SCK_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LED_1_Pin|PH_EN_Pin|RS485_RE_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_2_Pin */
  GPIO_InitStruct.Pin = LED_2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LC_DOUT_Pin */
  GPIO_InitStruct.Pin = LC_DOUT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(LC_DOUT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LC_SCK_Pin */
  GPIO_InitStruct.Pin = LC_SCK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LC_SCK_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LED_1_Pin PH_EN_Pin RS485_RE_Pin */
  GPIO_InitStruct.Pin = LED_1_Pin|PH_EN_Pin|RS485_RE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
