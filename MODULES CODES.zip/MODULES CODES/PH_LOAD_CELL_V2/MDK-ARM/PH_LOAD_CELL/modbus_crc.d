ph_load_cell/modbus_crc.o: ..\Core\Src\modbus_crc.c \
  ..\Core\Inc\modbus_crc.h
