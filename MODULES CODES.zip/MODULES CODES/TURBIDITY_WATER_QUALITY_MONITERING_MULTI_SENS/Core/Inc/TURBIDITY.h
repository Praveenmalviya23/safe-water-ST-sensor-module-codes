#ifndef __TURBIDITY_H
#define __TURBIDITY_H

#include <stdint.h>

typedef enum turb{
	FrameHeader_1 = 0x42,
	FrameHeader_2 = 0x4D,
	Module_Code = 0x62,
	ID_Code = 0x01,
	MCMD_RESET = 0x01,
 	MCMD_DATA = 0x02
}turb_e;

void requestTurbidity(void);
void resetTurbidity(void);


#endif
