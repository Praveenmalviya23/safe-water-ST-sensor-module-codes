/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32c0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LED2_Pin GPIO_PIN_15
#define LED2_GPIO_Port GPIOC
#define PRESSURE_SENS1_Pin GPIO_PIN_0
#define PRESSURE_SENS1_GPIO_Port GPIOA
#define LEVEL_SHIFT_EN_Pin GPIO_PIN_1
#define LEVEL_SHIFT_EN_GPIO_Port GPIOA
#define TURBIDITY_TX_Pin GPIO_PIN_2
#define TURBIDITY_TX_GPIO_Port GPIOA
#define TURBIDITY_RX_Pin GPIO_PIN_3
#define TURBIDITY_RX_GPIO_Port GPIOA
#define PRESSURE_SENS2_Pin GPIO_PIN_4
#define PRESSURE_SENS2_GPIO_Port GPIOA
#define SWITCH_1_Pin GPIO_PIN_6
#define SWITCH_1_GPIO_Port GPIOA
#define SWITCH_2_Pin GPIO_PIN_7
#define SWITCH_2_GPIO_Port GPIOA
#define RS485_RX_Pin GPIO_PIN_8
#define RS485_RX_GPIO_Port GPIOA
#define RS485_CTRL_Pin GPIO_PIN_12
#define RS485_CTRL_GPIO_Port GPIOA
#define RS485_TX_Pin GPIO_PIN_6
#define RS485_TX_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */
#define MODBUS_SLAVE_ID 3

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
