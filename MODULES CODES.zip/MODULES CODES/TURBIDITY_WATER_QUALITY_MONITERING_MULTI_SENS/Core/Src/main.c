/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdbool.h>
#include <stdio.h> // Required for printf
#include <math.h>  // Required for fmax and fmin (or you can implement them manually)
#include "modbusSlave.h"
#include <string.h>
#include "TURBIDITY.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

uint8_t  SLAVE_ID = MODBUS_SLAVE_ID; // MODBUS SLAVE ID

volatile uint16_t adcBuffer[3];
volatile uint16_t AdcConvertedBuffer[3];
volatile bool adcConversionCompleteFlag = false;

volatile uint8_t RS485_Rx_DATA[75];
volatile uint8_t RS485_Tx_DATA[75];


volatile uint8_t TURB_Rx_DATA[20];
volatile uint8_t TURB_Tx_DATA[10];

volatile unsigned long int millis =0;

volatile uint16_t sensedTurbidty;
volatile uint16_t sensedTemp;
volatile uint16_t mappedTurbidty;
volatile float turbRawAverage;

volatile uint8_t switch1State;
volatile uint8_t switch2State;

static uint32_t flowMillis = 0;
volatile uint32_t flowCounter =0;
volatile uint16_t flowRate;

unsigned long int ledMillis;
uint8_t checkSum = 0;

volatile uint32_t turbAccumulator = 0; // To store sum of ADC samples
volatile uint16_t turbSampleCount = 0;  // To count samples per second
//volatile uint16_t turbRawAverage = 0;   // Final 1-second average raw value
static uint32_t turbAveragingMillis = 0; // Timer for 1-second window

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
  adcConversionCompleteFlag = true;
	AdcConvertedBuffer[0] = adcBuffer[0];
	AdcConvertedBuffer[1] = adcBuffer[1];
	AdcConvertedBuffer[2] = adcBuffer[2]; // Turbidity on PA11
	
	// Accumulate samples triggered by TIM3 (every 10ms)
	turbAccumulator += AdcConvertedBuffer[2];
	turbSampleCount++;
}


void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	if(huart == &huart1){
		if (RS485_Rx_DATA[0] == SLAVE_ID)
		{
			switch (RS485_Rx_DATA[1]){
			case 0x03:
				readHoldingRegs();
				break;
			case 0x04:
				readInputRegs();
				break;
			case 0x01:
				readCoils();
				break;
			case 0x02:
				readInputs();
				break;
			case 0x06:
				writeSingleReg();
				break;
			case 0x10:
				writeHoldingRegs();
				break;
			case 0x05:
				writeSingleCoil();
				break;
			case 0x0F:
				writeMultiCoils();
				break;
			default:
				modbusException(ILLEGAL_FUNCTION);
				break;
			}
		}
		HAL_UARTEx_ReceiveToIdle_IT(&huart1, (uint8_t *)RS485_Rx_DATA, 75);
	}
	/*
	if(huart == &huart2){
		if(TURB_Rx_DATA[0] == FrameHeader_1 && TURB_Rx_DATA[1] == FrameHeader_2 && TURB_Rx_DATA[2] == Module_Code && TURB_Rx_DATA[3] == ID_Code){
			if(TURB_Rx_DATA[4] == 0x81){
				 // module is being reset
			}
			if(TURB_Rx_DATA[4] == 0x82){
				checkSum =0;
				for(int i=0;i<10;i++)
				checkSum +=TURB_Rx_DATA[i];
				checkSum = ~((checkSum) & 0xFF)+1;
				if(checkSum == TURB_Rx_DATA[10]){
					sensedTurbidty = TURB_Rx_DATA[6]<<8 | TURB_Rx_DATA[7];
					if(sensedTurbidty <= 200.0f) {
						mappedTurbidty = (sensedTurbidty / 20);
					} else {
						mappedTurbidty = (sensedTurbidty / 20);
					}
					// Not Connected determination by showing 111 when data 20< 
					if(mappedTurbidty > 30){
						mappedTurbidty = 111;
					}
					sensedTemp = TURB_Rx_DATA[8]<<8 | TURB_Rx_DATA[9];
				}
			}
		}

		HAL_UARTEx_ReceiveToIdle_IT(&huart2, (uint8_t *)TURB_Rx_DATA, 20);
	}*/
		
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	millis++;
}

//void HAL_GPIO_EXTI_Rising_Callback(uint16_t GPIO_Pin)
//{
//	flowCounter++;
//}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
	HAL_ADCEx_Calibration_Start(&hadc1);
  HAL_TIM_Base_Start_IT(&htim3);	
	HAL_ADC_Start_DMA(&hadc1,(uint32_t *)adcBuffer,3);
	readDataFromFlash();
	HAL_GPIO_WritePin(LEVEL_SHIFT_EN_GPIO_Port, LEVEL_SHIFT_EN_Pin, GPIO_PIN_SET);
	HAL_UARTEx_ReceiveToIdle_IT(&huart1, (uint8_t *)RS485_Rx_DATA, 75);
	HAL_UARTEx_ReceiveToIdle_IT(&huart2, (uint8_t *)TURB_Rx_DATA, 20);
//	flowMillis = millis;
//	flowCounter =0;
	ledMillis = millis;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		
		// ENABLE UART'S RX MODE
		HAL_UARTEx_ReceiveToIdle_IT(&huart1, (uint8_t *)RS485_Rx_DATA, 75);
		HAL_UARTEx_ReceiveToIdle_IT(&huart2, (uint8_t *)TURB_Rx_DATA, 20);
		
		// CHECK WHETHER PRESSURE DATA IS COLLECTED
		if(adcConversionCompleteFlag == true){
			adcConversionCompleteFlag = false; 
			// calculate the pressure here
			convertToPressure();			
		}
		
		// Read sates of switches
		switch1State = !(HAL_GPIO_ReadPin(SWITCH_1_GPIO_Port,SWITCH_1_Pin));
		switch2State = !(HAL_GPIO_ReadPin(SWITCH_2_GPIO_Port,SWITCH_2_Pin));
		
//		if(millis - flowMillis >= 1000){
//			flowMillis = millis;
//			float frequency = flowCounter / (1000*1000);
//			flowRate = (frequency / 7.5f)*100.0f;
//		}
		
		
			// Process 1-second Turbidity Average
			if (millis - turbAveragingMillis >= 1000) {
					turbAveragingMillis = millis;

					if (turbSampleCount > 0) {
							uint32_t currentAccumulator = turbAccumulator;
							uint16_t currentCount = turbSampleCount;
							turbAccumulator = 0;
							turbSampleCount = 0;

							turbRawAverage = (float)currentAccumulator / currentCount;

							// 1. Calculate the raw difference first to handle the "Cleaner than Baseline" case
							float diff = 2250.0f - turbRawAverage;

							if (diff <= 0) {
									// If raw is higher , for negative vlaues clamping
									 // ADC >= 2250 means water is perfectly clear
									mappedTurbidty = 0;
							} else {
								// Scale adjusted to 32.0f:
								// (2250 - 2100) / 32 = ~4.6 (Little dirty)
								// (2250 - 1300) / 32 = ~29.6 (Most dirty)
									float tempMapped = diff / 32.0f;
    
									// CAP DIRTY WATER AT 30 (Instead of jumping to 111)
									if (tempMapped > 30.0f) {
											mappedTurbidty = 30; 
									} else {
											mappedTurbidty = (uint16_t)tempMapped;
									}
							}

							// 2. Final Constraints and Error Handling
							// Trigger 111 if:
							// Raw is in the Air window (1700-1800) per observation
							//  Raw is extremely low (Disconnected/Module fault ~59.5)
							// Raw is extremely high (Sensor fault > 3500)
							 if ((turbRawAverage >= 1700 && turbRawAverage <= 1850) || turbRawAverage < 100 || turbRawAverage > 3500) {
									mappedTurbidty = 111;
							}
					}
			}
		// led toggling code
		if(millis -ledMillis >= 20){
			ledMillis = millis;
		//	HAL_GPIO_TogglePin(LED1_GPIO_Port,LED1_Pin);
		//	HAL_GPIO_TogglePin(LED2_GPIO_Port,LED2_Pin);
			//requestTurbidity();
		}
		fillDataIntoHoldingRegister();
  }
//	HAL_IWDG_Refresh(&hiwdg);
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_FLASH_SET_LATENCY(FLASH_LATENCY_1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_SEQ_FIXED;
  hadc1.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.LowPowerAutoPowerOff = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIG_T3_TRGO;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.SamplingTimeCommon1 = ADC_SAMPLETIME_12CYCLES_5;
  hadc1.Init.OversamplingMode = ENABLE;
  hadc1.Init.Oversampling.Ratio = ADC_OVERSAMPLING_RATIO_16;
  hadc1.Init.Oversampling.RightBitShift = ADC_RIGHTBITSHIFT_4;
  hadc1.Init.Oversampling.TriggeredMode = ADC_TRIGGEREDMODE_SINGLE_TRIGGER;
  hadc1.Init.TriggerFrequencyMode = ADC_TRIGGER_FREQ_HIGH;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_11;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 48-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 10000-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart1, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart1, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LEVEL_SHIFT_EN_Pin|RS485_CTRL_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED2_Pin */
  GPIO_InitStruct.Pin = LED2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LEVEL_SHIFT_EN_Pin RS485_CTRL_Pin */
  GPIO_InitStruct.Pin = LEVEL_SHIFT_EN_Pin|RS485_CTRL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : SWITCH_1_Pin SWITCH_2_Pin */
  GPIO_InitStruct.Pin = SWITCH_1_Pin|SWITCH_2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

// turbidity module functions
void requestTurbidity(void){
	uint8_t txBuffer[]={FrameHeader_1,FrameHeader_2,Module_Code,ID_Code,MCMD_DATA,0x00,0x0C};
	HAL_UART_Transmit(&huart2,txBuffer,7,100);	
}

void resetTurbidity(void){
	uint8_t txBuffer[]={FrameHeader_1,FrameHeader_2,Module_Code,ID_Code,MCMD_RESET,0x00,0x0D};
	HAL_UART_Transmit(&huart2,txBuffer,7,100);	
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
