water_quality_monitering_multi_sens/modbus_crc.o: \
  ..\Core\Src\modbus_crc.c ..\Core\Inc\modbus_crc.h
