/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "modbusSlave.h"
#include "modbus_crc.h"
#include <stdbool.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
volatile uint8_t RxData[50];
volatile uint8_t TxData[50];
uint8_t  SLAVE_ID= MODBUS_SLAVE_ID;
uint16_t calScale[3];
uint16_t calOffset[3];
volatile bool timInterrupt = false;

volatile uint8_t TdsTxBuffer[50];
volatile uint8_t TdsRxBuffer[50];

volatile uint16_t tdsChannel1;
volatile uint16_t tempChannel1;
volatile uint16_t tdsChannel2;
volatile uint16_t tempChannel2;

extern volatile uint16_t calTdsChannel1;
extern volatile uint16_t calTempChannel1;
extern volatile uint16_t calTdsChannel2;
extern volatile uint16_t calTempChannel2;

volatile bool channel1TdsCalbritation = false;
volatile bool channel1NtcCalbritation = false;
volatile bool channel2TdsCalbritation = false;
volatile bool channel2NtcCalbritation = false;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */
void requestChannel1(void);
void requestChannel2(void);
void CalibrateTdsChannel1(uint16_t tds1);
void CalibrateTdsChannel2(uint16_t tds2);
void convertToPressure(void);
void CalibrateNtcChannel2(uint16_t ntc2);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	if (huart->Instance == USART2) // Check if the interrupt is from the correct UART2
	{
		if (RxData[0] == SLAVE_ID)
		{
			switch (RxData[1]){
			case 0x03:
				readHoldingRegs();
				break;
			case 0x04:
				readInputRegs();
				break;
			case 0x01:
				readCoils();
				break;
			case 0x02:
				readInputs();
				break;
			case 0x06:
				writeSingleReg();
				break;
			case 0x10:
				writeHoldingRegs();
				break;
			case 0x05:
				writeSingleCoil();
				break;
			case 0x0F:
				writeMultiCoils();
				break;
			default:
				modbusException(ILLEGAL_FUNCTION);
				break;
			}
		}
		
	}
	
	
	if (huart->Instance == USART1) // Check if the interrupt is from the correct UART1
	{
		// get the temperature of first channel		
		// get the tds of first channel
		if (TdsRxBuffer[3] == 0x01) {
      tempChannel1 = (TdsRxBuffer[6] << 8 | (uint16_t)TdsRxBuffer[7]) / 10;
      tdsChannel1 = (TdsRxBuffer[4] << 8 | (uint16_t)TdsRxBuffer[5]) / 10;
    }
		
		// get the temperature of second channel
		// get the tds of second channel
		if (TdsRxBuffer[3] == 0x02) {
      tempChannel2 = (TdsRxBuffer[6] << 8 | (uint16_t)TdsRxBuffer[7]) / 10;
      tdsChannel2 = (TdsRxBuffer[4] << 8 | (uint16_t)TdsRxBuffer[5]) / 10;
    }
		
				

	}
	HAL_UARTEx_ReceiveToIdle_IT(&huart1, (uint8_t *)TdsRxBuffer, 50);
	HAL_UARTEx_ReceiveToIdle_IT(&huart2, (uint8_t *)RxData, 50);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	timInterrupt = true;
//	HAL_GPIO_TogglePin(LED_1_GPIO_Port,LED_1_Pin);
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
	readDataFromFlash();
	HAL_TIM_Base_Start_IT(&htim3);
	HAL_UARTEx_ReceiveToIdle_IT(&huart2, (uint8_t *)RxData, 50);
	HAL_UARTEx_ReceiveToIdle_IT(&huart1, (uint8_t *)TdsRxBuffer, 50);
	HAL_GPIO_WritePin(TDS_EN_GPIO_Port,TDS_EN_Pin,GPIO_PIN_SET);
	HAL_GPIO_WritePin(LEVEL_SHIFTER_EN_GPIO_Port,LEVEL_SHIFTER_EN_Pin,GPIO_PIN_SET);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		HAL_UARTEx_ReceiveToIdle_IT(&huart1, (uint8_t *)TdsRxBuffer, 50);
		HAL_UARTEx_ReceiveToIdle_IT(&huart2, (uint8_t *)RxData, 50);
		fillDataIntoHoldingRegister();
		if(timInterrupt){
			timInterrupt = false;
			static bool ChannelSelector = false;
			
			if(channel1TdsCalbritation == true){
				
				HAL_GPIO_WritePin(TDS_EN_GPIO_Port,TDS_EN_Pin,GPIO_PIN_RESET);
				HAL_Delay(50);
				HAL_GPIO_WritePin(TDS_EN_GPIO_Port,TDS_EN_Pin,GPIO_PIN_SET);
				HAL_Delay(50);
				CalibrateTdsChannel1(calTdsChannel1);
				HAL_Delay(10);
				CalibrateTdsChannel1(calTdsChannel1);
				HAL_Delay(10);
				channel1TdsCalbritation = false;
			}
			else if(channel1NtcCalbritation == true){
				HAL_GPIO_WritePin(TDS_EN_GPIO_Port,TDS_EN_Pin,GPIO_PIN_RESET);
				HAL_Delay(50);
				HAL_GPIO_WritePin(TDS_EN_GPIO_Port,TDS_EN_Pin,GPIO_PIN_SET);
				HAL_Delay(50);
				CalibrateNtcChannel1(calTempChannel1);
				HAL_Delay(10);
				CalibrateNtcChannel1(calTempChannel1);
				HAL_Delay(10);
				channel1NtcCalbritation = false;
				
			}
			else if(channel2TdsCalbritation == true){
				
				HAL_GPIO_WritePin(TDS_EN_GPIO_Port,TDS_EN_Pin,GPIO_PIN_RESET);
				HAL_Delay(50);
				HAL_GPIO_WritePin(TDS_EN_GPIO_Port,TDS_EN_Pin,GPIO_PIN_SET);
				HAL_Delay(50);
				CalibrateTdsChannel2(calTdsChannel2);
				HAL_Delay(10);
				CalibrateTdsChannel2(calTdsChannel2);
				HAL_Delay(10);
				channel2TdsCalbritation = false;
			}
			else if(channel2NtcCalbritation == true){
								
				HAL_GPIO_WritePin(TDS_EN_GPIO_Port,TDS_EN_Pin,GPIO_PIN_RESET);
				HAL_Delay(50);
				HAL_GPIO_WritePin(TDS_EN_GPIO_Port,TDS_EN_Pin,GPIO_PIN_SET);
				HAL_Delay(50);
				CalibrateNtcChannel2(calTempChannel2);
				HAL_Delay(10);
				CalibrateNtcChannel2(calTempChannel2);
				HAL_Delay(10);
				channel2NtcCalbritation = false;
			}
			else{
				
			if(ChannelSelector == false){
				// get Channel first data			
				requestChannel1();
				HAL_GPIO_TogglePin(LED_1_GPIO_Port,LED_1_Pin);
			}
			else {
				// get Channel second data
				requestChannel2();
//				HAL_GPIO_TogglePin(LED_1_GPIO_Port,LED_1_Pin);
			}
			ChannelSelector = !ChannelSelector;
			
		}
			
		}
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_FLASH_SET_LATENCY(FLASH_LATENCY_0);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV4;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 12-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 10000-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart1, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart1, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_1_GPIO_Port, LED_1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, RS485_RE_Pin|LEVEL_SHIFTER_EN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(TDS_EN_GPIO_Port, TDS_EN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_1_Pin */
  GPIO_InitStruct.Pin = LED_1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : RS485_RE_Pin LEVEL_SHIFTER_EN_Pin */
  GPIO_InitStruct.Pin = RS485_RE_Pin|LEVEL_SHIFTER_EN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : TDS_EN_Pin */
  GPIO_InitStruct.Pin = TDS_EN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(TDS_EN_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void requestChannel1(void) {
  TdsTxBuffer[0] = 0x55;
  TdsTxBuffer[1] = 0x07;
  TdsTxBuffer[2] = 0X05;
  TdsTxBuffer[3] = 0X01;
  TdsTxBuffer[4] = 0X00;
  TdsTxBuffer[5] = 0X00;
  TdsTxBuffer[6] = 0X00;
  TdsTxBuffer[7] = 0X62;
 HAL_UART_Transmit(&huart1,(uint8_t *)TdsTxBuffer,8,200);
}


void requestChannel2(void) {
  TdsTxBuffer[0] = 0x55;
  TdsTxBuffer[1] = 0x07;
  TdsTxBuffer[2] = 0X05;
  TdsTxBuffer[3] = 0X02;
  TdsTxBuffer[4] = 0X00;
  TdsTxBuffer[5] = 0X00;
  TdsTxBuffer[6] = 0X00;
  TdsTxBuffer[7] = 0X63;
 HAL_UART_Transmit(&huart1,(uint8_t *)TdsTxBuffer,8,200);
}

void CalibrateTdsChannel1(uint16_t tds1) {
  TdsTxBuffer[0] = 0x55;
  TdsTxBuffer[1] = 0x07;
  TdsTxBuffer[2] = 0X03;
  TdsTxBuffer[3] = 0X01;
	TdsTxBuffer[4] = 0x01;
  TdsTxBuffer[5] = (tds1>>8)&0xFF;
  TdsTxBuffer[6] = tds1&0xFF;
  TdsTxBuffer[7] = TdsTxBuffer[0]+TdsTxBuffer[1]+TdsTxBuffer[2]+TdsTxBuffer[3]+TdsTxBuffer[4]+TdsTxBuffer[5]+TdsTxBuffer[6];
 HAL_UART_Transmit(&huart1,(uint8_t *)TdsTxBuffer,8,200);
}

void CalibrateTdsChannel2(uint16_t tds2) {
  TdsTxBuffer[0] = 0x55;
  TdsTxBuffer[1] = 0x07;
  TdsTxBuffer[2] = 0X03;
  TdsTxBuffer[3] = 0X02;
	TdsTxBuffer[4] = 0x01;
  TdsTxBuffer[5] = ((tds2>>8)&0xff);
  TdsTxBuffer[6] = (tds2&0xff);
  TdsTxBuffer[7] = TdsTxBuffer[0]+TdsTxBuffer[1]+TdsTxBuffer[2]+TdsTxBuffer[3]+TdsTxBuffer[4]+TdsTxBuffer[5]+TdsTxBuffer[6];
 HAL_UART_Transmit(&huart1,(uint8_t *)TdsTxBuffer,8,200);
}


void CalibrateNtcChannel1(uint16_t ntc1) {
  TdsTxBuffer[0] = 0x55;
  TdsTxBuffer[1] = 0x07;
  TdsTxBuffer[2] = 0X04;
  TdsTxBuffer[3] = 0X01;
  TdsTxBuffer[4] = ((ntc1>>8)&0xff);
  TdsTxBuffer[5] = (ntc1&0xff);
	TdsTxBuffer[6] = 0x00;
  TdsTxBuffer[7] = TdsTxBuffer[0]+TdsTxBuffer[1]+TdsTxBuffer[2]+TdsTxBuffer[3]+TdsTxBuffer[4]+TdsTxBuffer[5]+TdsTxBuffer[6];
	HAL_UART_Transmit(&huart1,(uint8_t *)TdsTxBuffer,8,200);
}

void CalibrateNtcChannel2(uint16_t ntc2) {
  TdsTxBuffer[0] = 0x55;
  TdsTxBuffer[1] = 0x07;
  TdsTxBuffer[2] = 0X04;
  TdsTxBuffer[3] = 0X02;
  TdsTxBuffer[4] = ((ntc2>>8)&0xff);
  TdsTxBuffer[5] = (ntc2&0xff);
	TdsTxBuffer[6] = 0x00;
  TdsTxBuffer[7] = TdsTxBuffer[0]+TdsTxBuffer[1]+TdsTxBuffer[2]+TdsTxBuffer[3]+TdsTxBuffer[4]+TdsTxBuffer[5]+TdsTxBuffer[6];
 HAL_UART_Transmit(&huart1,(uint8_t *)TdsTxBuffer,8,200);
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
